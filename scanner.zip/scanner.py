import os
import requests
import json
from http.server import HTTPServer, BaseHTTPRequestHandler

def make_dict(lst):
    lst_dict = dict()
    if lst:
        for header in lst:
            header_name = header.split(':')[0]
            header_value = header.split(':')[1:]
            lst_dict[header_name] = ':'.join(header_value)

    return lst_dict

def do_ping_sweep(ip, num_of_host):
    ip_parts = ip.split('.')
    network_ip = ip_parts[0] + '.' + ip_parts[1] + '.' + ip_parts[2] + '.'
    scanned_ip = network_ip + str(int(ip_parts[3]) + num_of_host)
    response = os.popen(f'ping -c 3 -n 1 {scanned_ip}')
    res = response.readlines()
    print(f"[#] Result of scanning: {scanned_ip} [#]\n{res[2]}", end='\n\n')

def sent_http_request(target, method, headers=None, payload=None):
    headers_dict = dict()
    if headers:
        for header in headers:
            header_name = header.split(':')[0]
            header_value = header.split(':')[1:]
            headers_dict[header_name] = ':'.join(header_value)
    make_dict(headers)
    if method == "GET":
        response = requests.get(target, headers=headers_dict)
    elif method == "POST":
        response = requests.post(target, headers=headers_dict, data=payload)
    print(
        f"[#] Response status code: {response.status_code}\n"
        f"[#] Response headers: {json.dumps(dict(response.headers), indent=4, sort_keys=True)}\n"
        f"[#] Response content:\n {response.text}"
    )

#Обработка запросов
class ServiceHandler(BaseHTTPRequestHandler):
    #set headers parameters for answer
    def set_headers(self):
        self.send_response(200)
        self.send_header("Content-type", "text/json")
        length = int(self.headers["Content-Length"])
        content = self.rfile.read(length)
        temp = str(content).strip('b\'')
        self.end_headers()
        return temp

    #working on GET requests
    def do_GET(self):
        temp = self.set_headers()
        string = temp.translate({ord(i): None for i in ' }\'\"{'})
        lst = string.split(',')
        header_dict = make_dict(lst)

        if 'task' in header_dict.keys():
            task = header_dict.get('task')

            if task == 'scan':
                if 'count' in header_dict.keys():
                    count = int(header_dict.get('count'))

                if 'target' in header_dict.keys():
                    ip = header_dict.get('target')

                for host_num in range(count):
                    do_ping_sweep(ip, host_num)

                self.wfile.write((f"Scaning {ip} complete!").encode())



    #working on POST requests
    def do_POST(self):
        temp = self.set_headers()
        string = temp.translate({ord(i): None for i in ' }\'\"{'})
        lst = string.split(',')
        header_dict = make_dict(lst)

        if 'task' in header_dict.keys():
            task = header_dict.get('task')
            if task == 'sendhttp':
                if 'Target' in header_dict.keys():
                    target = header_dict.get('Target')

                if 'Method' in header_dict.keys():
                    method = header_dict.get('Method')

                headers = []
                if 'Header' and 'Header-value' in header_dict.keys():
                    header = header_dict.get('Header') + ':' + header_dict.get('Header-value')
                    headers.append(header)

                payload = ''
                if headers:
                    if 'Payload' in header_dict.keys():
                        payload = header_dict.get('Payload')

                sent_http_request(target, method, headers, payload)

            self.wfile.write((f"Sendhttp complete!").encode())

#Run HTTP server
server = HTTPServer(('0.0.0.0', 8081), ServiceHandler)
server.serve_forever()
